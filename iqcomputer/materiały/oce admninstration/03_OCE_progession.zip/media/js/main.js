var includes = [
    "lib/global.js",
    "components/tools.js",
    "lib/config.js",
    "lib/viview.js",
    "vendor/jquery-1.9.1.min.js",
    "components/feedbacker.js",
    "components/drawer.js"
];

for(var i=0;i<includes.length;i++) {
    document.write('<script src="media/js/' + includes[i] + '" type="text/javascript"></script>');
}

var drawer;

function Initialize() {
    var feedbacker = new Feedbacker();
    feedbacker.initialize();
    
    drawer = new Drawer();
    drawer.initialize();
}

function RestoreInitialState() {
    drawer.stop();
}