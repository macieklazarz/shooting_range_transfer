function Tools() {}

Tools.prototype.Maths = {
    getRandomInt: function(_min, _max) {
        return (Math.floor(Math.random() * (_max - _min + 1)) + _min);
    }
}

Tools.prototype.File = {
    includeJS: function(_path) {
        document.write('<script type="text/javascript" src="' + _path + '"></script>');
    }
}

Tools.prototype.LocalStorage = {
    set: function(_key, _value) {
        localStorage.setItem(_key, _value);
    },
    
    get: function(_key) {
        var theItem = localStorage.getItem(_key);
        if(theItem == undefined || theItem == null || theItem == "null" || theItem == "") {
            theItem = null;
        }
        return theItem;
    }
}