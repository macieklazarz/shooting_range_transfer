var includes = [
    "lib/global.js",
    "components/tools.js",
    "lib/config.js",
    "lib/viview.js",
    "vendor/jquery-1.9.1.min.js",
    "components/feedbacker.js"
];

for(var i=0;i<includes.length;i++) {
    document.write('<script src="media/js/' + includes[i] + '" type="text/javascript"></script>');
}

function Initialize() {
    var feedbacker = new Feedbacker();
    feedbacker.initialize();
}

function RestoreInitialState() {
    
}